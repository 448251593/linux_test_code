/**
 * @file util.c some general util functions
 *
 * Copyright (C) 2016 Xiaomi
 */
