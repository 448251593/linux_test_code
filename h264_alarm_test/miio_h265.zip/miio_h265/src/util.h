#ifndef __UTIL_H
#define __UTIL_H
#define _GNU_SOURCE
#include <miio/log.h>
#include <errno.h>
#endif
